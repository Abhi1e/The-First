namespace Recommerce.Infrastructure.Constants;

public static class ApiResultStatusCodeMessageConstants
{
    public const string UnAuthorizedMessage = "خطای احراز هویت";
    public const string ServerErrorMessage = "خطایی در سرور رخ داده است";
}