namespace Recommerce.Data.Enums;

public enum ReviewEmotionType
{
    Neutral = 0,
    Positive = 1,
    Negative = 2
}