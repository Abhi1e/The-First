namespace Recommerce.Data.Enums;

public enum GenderType
{
    UnKnown = 0,
    Man = 1,
    WoMen = 2
}