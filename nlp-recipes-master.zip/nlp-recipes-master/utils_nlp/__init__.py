# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

__title__ = "Microsoft NLP"
__author__ = "AI CAT at Microsoft"
__license__ = "MIT"
__copyright__ = "Copyright 2018-present Microsoft Corporation"
__version__ = "2.0.0"

# Synonyms
TITLE = __title__
AUTHOR = __author__
LICENSE = __license__
COPYRIGHT = __copyright__
VERSION = __version__
