# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

SNLI_CLEAN_PATH = "clean/snli_1.0"
